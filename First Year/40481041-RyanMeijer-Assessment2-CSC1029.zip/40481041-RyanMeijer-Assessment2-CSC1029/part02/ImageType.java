package part02;

public enum ImageType {
ASTRONOMY,
ARCHITECTURE,
SPORT,
LANDSCAPE,
PORTRAIT,
NATURE,
AERIAL,
FOOD,
OTHER;
}
